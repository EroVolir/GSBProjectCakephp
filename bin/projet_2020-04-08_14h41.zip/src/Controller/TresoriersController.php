<?php

namespace App\Controller;

use Cake\Event\Event;
use App\Controller\AppController;

class TresoriersController extends AppController
{
public function isAuthorized($user) {
  return true;
}

   public function index() {
       $this->loadModel('Users');
       $joueurs = file('csv/joueurs-2020.csv');
       array_shift($joueurs);
       foreach ($joueurs as $joueur) {
           //debug($joueur);
           $data = explode(",", $joueur);
           //debug($data);
           $user = $this->Users->newEntity();
           $user->nom = $data[0];
           $user->prenom = $data[1];
           $user->num_licence = $data[2];
           $user->username = $data[3];
           $user->password = "secret";
           $user->role = "joueur";
           if ($this->Users->save($user)) {
               debug("ok");
           } else {
               debug($user->errors());
           }
       }
       $this->autoRender = FALSE;
   }
}
