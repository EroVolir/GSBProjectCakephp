<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Parametres Model
 *
 * @method \App\Model\Entity\Parametre get($primaryKey, $options = [])
 * @method \App\Model\Entity\Parametre newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Parametre[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Parametre|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Parametre saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Parametre patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Parametre[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Parametre findOrCreate($search, callable $callback = null, $options = [])
 */
class ParametresTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('parametres');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->scalar('club')
            ->maxLength('club', 50)
            ->allowEmptyString('club');

        $validator
            ->decimal('indem_kms')
            ->allowEmptyString('indem_kms');

        return $validator;
    }
}
