<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * ParametresFixture
 */
class ParametresFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'club' => ['type' => 'string', 'length' => 50, 'null' => true, 'default' => null, 'collate' => 'French_CI_AS', 'precision' => null, 'comment' => null, 'fixed' => null],
        'indem_kms' => ['type' => 'decimal', 'length' => 19, 'precision' => 4, 'null' => true, 'default' => null, 'comment' => null, 'unsigned' => null],
    ];
    // @codingStandardsIgnoreEnd
    /**
     * Init method
     *
     * @return void
     */
    public function init()
    {
        $this->records = [
            [
                'club' => 'Lorem ipsum dolor sit amet',
                'indem_kms' => 1.5
            ],
        ];
        parent::init();
    }
}
