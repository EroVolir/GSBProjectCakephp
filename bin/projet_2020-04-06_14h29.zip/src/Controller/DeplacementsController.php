<?php
namespace App\Controller;
use Cake\Event\Event;
use App\Controller\AppController;

/**
 * Deplacements Controller
 *
 * @property \App\Model\Table\DeplacementsTable $Deplacements
 *
 * @method \App\Model\Entity\Deplacement[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class DeplacementsController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Equipes', 'Villes', 'Users', 'Etats']
        ];
        $deplacements = $this->paginate($this->Deplacements);

        $this->set(compact('deplacements'));
    }

    /**
     * View method
     *
     * @param string|null $id Deplacement id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $deplacement = $this->Deplacements->get($id, [
            'contain' => ['Equipes', 'Villes', 'Users', 'Etats']
        ]);

        $this->set('deplacement', $deplacement);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $deplacement = $this->Deplacements->newEntity();
        if ($this->request->is('post')) {
            $deplacement = $this->Deplacements->patchEntity($deplacement, $this->request->getData());
            if ($this->Deplacements->save($deplacement)) {
                $this->Flash->success(__('The deplacement has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The deplacement could not be saved. Please, try again.'));
        }
        $equipes = $this->Deplacements->Equipes->find('list', ['limit' => 200]);
        $villes = $this->Deplacements->Villes->find('list', ['limit' => 200]);
        $users = $this->Deplacements->Users->find('list', ['limit' => 200]);
        $etats = $this->Deplacements->Etats->find('list', ['limit' => 200]);
        $this->set(compact('deplacement', 'equipes', 'villes', 'users', 'etats'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Deplacement id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $deplacement = $this->Deplacements->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $deplacement = $this->Deplacements->patchEntity($deplacement, $this->request->getData());
            if ($this->Deplacements->save($deplacement)) {
                $this->Flash->success(__('The deplacement has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The deplacement could not be saved. Please, try again.'));
        }
        $equipes = $this->Deplacements->Equipes->find('list', ['limit' => 200]);
        $villes = $this->Deplacements->Villes->find('list', ['limit' => 200]);
        $users = $this->Deplacements->Users->find('list', ['limit' => 200]);
        $etats = $this->Deplacements->Etats->find('list', ['limit' => 200]);
        $this->set(compact('deplacement', 'equipes', 'villes', 'users', 'etats'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Deplacement id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $deplacement = $this->Deplacements->get($id);
        if ($this->Deplacements->delete($deplacement)) {
            $this->Flash->success(__('The deplacement has been deleted.'));
        } else {
            $this->Flash->error(__('The deplacement could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

    public function beforeFilter(Event $event)
{
    parent::beforeFilter($event);
    $this->Auth->deny(['add']);
}

public function isAuthorized($user) {
    if ($this->request->action === 'add') {
        if (isset($user['role']) && $user['role'] === 'tresorier') {
            return true;
        } else {
            $this->Flash->error(__('Cette action n\'est pas autorisée !'));
            return false;
        }
    }
    if ($this->request->action === 'delete') {
        if (isset($user['role']) && $user['role'] === 'tresorier') {
            return true;
        } else {
            $this->Flash->error(__('Cette action n\'est pas autorisée !'));
            return false;
        }
    }
    return true;
}

}
