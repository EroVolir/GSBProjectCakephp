<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Deplacement Entity
 *
 * @property int $id
 * @property int $equipe_id
 * @property \Cake\I18n\FrozenDate|null $datejour
 * @property float|null $montant
 * @property bool|null $don
 * @property int $ville_id
 * @property int|null $user_id
 * @property int $etat_id
 *
 * @property \App\Model\Entity\Equipe $equipe
 * @property \App\Model\Entity\Ville $ville
 * @property \App\Model\Entity\User $user
 * @property \App\Model\Entity\Etat $etat
 */
class Deplacement extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'equipe_id' => true,
        'datejour' => true,
        'montant' => true,
        'don' => true,
        'ville_id' => true,
        'user_id' => true,
        'etat_id' => true,
        'equipe' => true,
        'ville' => true,
        'user' => true,
        'etat' => true
    ];
}
