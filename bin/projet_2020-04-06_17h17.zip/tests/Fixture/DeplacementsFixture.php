<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * DeplacementsFixture
 */
class DeplacementsFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'id' => ['type' => 'integer', 'length' => 10, 'autoIncrement' => true, 'null' => false, 'default' => null, 'precision' => null, 'comment' => null, 'unsigned' => null],
        'equipe_id' => ['type' => 'integer', 'length' => 10, 'null' => false, 'default' => null, 'precision' => null, 'comment' => null, 'unsigned' => null, 'autoIncrement' => null],
        'datejour' => ['type' => 'date', 'length' => null, 'null' => true, 'default' => null, 'precision' => null, 'comment' => null],
        'montant' => ['type' => 'decimal', 'length' => 19, 'precision' => 4, 'null' => true, 'default' => null, 'comment' => null, 'unsigned' => null],
        'don' => ['type' => 'boolean', 'length' => null, 'null' => true, 'default' => 0, 'precision' => null, 'comment' => null],
        'ville_id' => ['type' => 'integer', 'length' => 10, 'null' => false, 'default' => null, 'precision' => null, 'comment' => null, 'unsigned' => null, 'autoIncrement' => null],
        'user_id' => ['type' => 'integer', 'length' => 10, 'null' => true, 'default' => null, 'precision' => null, 'comment' => null, 'unsigned' => null, 'autoIncrement' => null],
        'etat_id' => ['type' => 'integer', 'length' => 10, 'null' => false, 'default' => null, 'precision' => null, 'comment' => null, 'unsigned' => null, 'autoIncrement' => null],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id'], 'length' => []],
            'FK_deplacements_villes' => ['type' => 'foreign', 'columns' => ['ville_id'], 'references' => ['villes', 'id'], 'update' => 'noAction', 'delete' => 'noAction', 'length' => []],
            'FK_deplacements_etats' => ['type' => 'foreign', 'columns' => ['etat_id'], 'references' => ['etats', 'id'], 'update' => 'noAction', 'delete' => 'noAction', 'length' => []],
            'FK_deplacements_equipes' => ['type' => 'foreign', 'columns' => ['equipe_id'], 'references' => ['equipes', 'id'], 'update' => 'noAction', 'delete' => 'noAction', 'length' => []],
            'FK_deplacements_users' => ['type' => 'foreign', 'columns' => ['user_id'], 'references' => ['users', 'id'], 'update' => 'noAction', 'delete' => 'noAction', 'length' => []],
        ],
    ];
    // @codingStandardsIgnoreEnd
    /**
     * Init method
     *
     * @return void
     */
    public function init()
    {
        $this->records = [
            [
                'id' => 1,
                'equipe_id' => 1,
                'datejour' => '2020-04-06',
                'montant' => 1.5,
                'don' => 1,
                'ville_id' => 1,
                'user_id' => 1,
                'etat_id' => 1
            ],
        ];
        parent::init();
    }
}
