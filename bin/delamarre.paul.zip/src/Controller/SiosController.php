<?php
namespace App\Controller;

use Cake\Controller\Controller;

/**
 * CakePHP SiosController
 * @author sios
 */
class SiosController extends AppController {

    public function index($nom="") {
      $this->set('nom', $nom);
      $this->render('index');

    }

    public function stages() {

    }

    public function modules($index="") {
      $this->set('index', $index);
      $this->render('modules');

    }

    public function filtreModule() {

    }

    public function tousLesModules() {
    $datas = [];
    $slams = file('../datas/modules-slam.csv');
    foreach($slams as $slam) {
        $datas[] = explode(';',$slam);
    }
    $this->set('slams', $datas);
}

  public function tousLesEtudiants() {
  $datas = [];
  $etudiants = file('../datas/sio2019_option.csv');
  foreach($etudiants as $etudiant) {
      $datas[] = explode(';',$etudiant);
    }
    $this->set('etudiants', $datas);
  }

}
