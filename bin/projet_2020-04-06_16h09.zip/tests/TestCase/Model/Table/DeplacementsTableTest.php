<?php
namespace App\Test\TestCase\Model\Table;

use App\Model\Table\DeplacementsTable;
use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\DeplacementsTable Test Case
 */
class DeplacementsTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\DeplacementsTable
     */
    public $Deplacements;

    /**
     * Fixtures
     *
     * @var array
     */
    public $fixtures = [
        'app.Deplacements',
        'app.Equipes',
        'app.Villes',
        'app.Users',
        'app.Etats'
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp()
    {
        parent::setUp();
        $config = TableRegistry::getTableLocator()->exists('Deplacements') ? [] : ['className' => DeplacementsTable::class];
        $this->Deplacements = TableRegistry::getTableLocator()->get('Deplacements', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown()
    {
        unset($this->Deplacements);

        parent::tearDown();
    }

    /**
     * Test initialize method
     *
     * @return void
     */
    public function testInitialize()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test buildRules method
     *
     * @return void
     */
    public function testBuildRules()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
