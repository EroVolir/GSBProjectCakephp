<?php
namespace App\Controller;
use Cake\Event\Event;
use App\Controller\AppController;

/**
 * Parametres Controller
 *
 * @property \App\Model\Table\ParametresTable $Parametres
 *
 * @method \App\Model\Entity\Parametre[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class ParametresController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $parametres = $this->paginate($this->Parametres);

        $this->set(compact('parametres'));
    }

    /**
     * View method
     *
     * @param string|null $id Parametre id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $parametre = $this->Parametres->get($id, [
            'contain' => []
        ]);

        $this->set('parametre', $parametre);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $parametre = $this->Parametres->newEntity();
        if ($this->request->is('post')) {
            $parametre = $this->Parametres->patchEntity($parametre, $this->request->getData());
            if ($this->Parametres->save($parametre)) {
                $this->Flash->success(__('The parametre has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The parametre could not be saved. Please, try again.'));
        }
        $this->set(compact('parametre'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Parametre id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $parametre = $this->Parametres->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $parametre = $this->Parametres->patchEntity($parametre, $this->request->getData());
            if ($this->Parametres->save($parametre)) {
                $this->Flash->success(__('The parametre has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The parametre could not be saved. Please, try again.'));
        }
        $this->set(compact('parametre'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Parametre id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $parametre = $this->Parametres->get($id);
        if ($this->Parametres->delete($parametre)) {
            $this->Flash->success(__('The parametre has been deleted.'));
        } else {
            $this->Flash->error(__('The parametre could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

    public function beforeFilter(Event $event)
    {
    parent::beforeFilter($event);
    $this->Auth->deny(['add']);
  }

  public function isAuthorized($user) {
      if ($this->request->action === 'add') {
          if (isset($user['role']) && $user['role'] === 'tresaurier') {
              return true;
          } else {
              $this->Flash->error(__('Cette action n\'est pas autorisée !'));
              return false;
          }
      }
      if ($this->request->action === 'delete') {
          if (isset($user['role']) && $user['role'] === 'tresaurier') {
              return true;
          } else {
              $this->Flash->error(__('Cette action n\'est pas autorisée !'));
              return false;
          }
      }
      if ($this->request->action === 'edit') {
          if (isset($user['role']) && $user['role'] === 'tresaurier') {
              return true;
          } else {
              $this->Flash->error(__('Cette action n\'est pas autorisée !'));
              return false;
          }
      }
      return true;
  }
}
