<?php
namespace App\Controller;

use App\Controller\AppController;

use Cake\Event\Event;


/**
 * Exposes Controller
 *
 * @property \App\Model\Table\ExposesTable $Exposes
 *
 * @method \App\Model\Entity\Expose[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class ExposesController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Users']
        ];
        $exposes = $this->paginate($this->Exposes);

        $this->set(compact('exposes'));
    }

    public function beforeFilter(Event $event)
   {
       parent::beforeFilter($event);
       $this->Auth->deny(['add']);
   }

    /**
     * View method
     *
     * @param string|null $id Expose id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $expose = $this->Exposes->get($id, [
            'contain' => ['Users']
        ]);

        $this->set('expose', $expose);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $expose = $this->Exposes->newEntity();
        if ($this->request->is('post')) {
            $expose = $this->Exposes->patchEntity($expose, $this->request->getData());
            if ($this->Exposes->save($expose)) {
                $this->Flash->success(__('The expose has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The expose could not be saved. Please, try again.'));
        }
        $users = $this->Exposes->Users->find('list', ['limit' => 200]);
        $this->set(compact('expose', 'users'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Expose id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $expose = $this->Exposes->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $expose = $this->Exposes->patchEntity($expose, $this->request->getData());
            if ($this->Exposes->save($expose)) {
                $this->Flash->success(__('The expose has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The expose could not be saved. Please, try again.'));
        }
        $users = $this->Exposes->Users->find('list', ['limit' => 200]);
        $this->set(compact('expose', 'users'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Expose id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $expose = $this->Exposes->get($id);
        if ($this->Exposes->delete($expose)) {
            $this->Flash->success(__('The expose has been deleted.'));
        } else {
            $this->Flash->error(__('The expose could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

    public function isAuthorized($user) {
      if (isset($user['username']) && $user['username'] === 'admin') {
        return true;
    }
    if ($this->request->action === 'edit') {
        $exposeId = (int) $this->request->params['pass'][0];
        if ($this->Exposes->isOwnedBy($exposeId, $user['id'])) {
            return true;
        } else {
            $this->Flash->error(__('Vous n\'êtes pas l\'auteur de cet exposé !'));
            return false;
        }
    }
    if ($this->request->action === 'delete') {
        $exposeId = (int) $this->request->params['pass'][0];
        if ($this->Exposes->isOwnedBy($exposeId, $user['id'])) {
            return true;
        } else {
            $this->Flash->error(__('Vous n\'êtes pas l\'auteur de cet exposé !'));
            return false;
        }
    }
    return true;
}

}
